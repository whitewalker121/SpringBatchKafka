package com.springbatch.springbatchexample1.repository;

import com.springbatch.springbatchexample1.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<Message, Integer> {
}
