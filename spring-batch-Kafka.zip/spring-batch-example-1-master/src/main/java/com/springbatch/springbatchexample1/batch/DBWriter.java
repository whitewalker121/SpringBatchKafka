package com.springbatch.springbatchexample1.batch;

import com.springbatch.springbatchexample1.model.Message;
import com.springbatch.springbatchexample1.repository.MessageRepository;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DBWriter implements ItemWriter<Message> {
    @Autowired
    KafkaTemplate kafkaTemplate;

    @Autowired
    private MessageRepository repository;

    @Override
    public void write(List<? extends Message> messages) throws Exception {

        System.out.println("Data Saved for messages: " + messages);
        repository.save(messages);
        for(Message message:messages)
        kafkaTemplate.send("springBatch",message);
    }
}
