package com.springbatch.springbatchexample1.batch;

import com.springbatch.springbatchexample1.model.Message;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class Processor implements ItemProcessor<Message, Message> {

    private static final Map<String, String> sources =
            new HashMap<>();

    public Processor() {
        sources.put("API", "web service");
        sources.put("MOBILE", "android device");
    }

    @Override
    public Message process(Message message) throws Exception {
        String source=message.getSource();
       message.setSource(sources.get(source));
        message.setTime(new Date());
        System.out.println(String.format("Converted from [%s] to [%s]", source, message.getSource()));
        return message;
    }
}
