package com.springbatch.springbatchexample1.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class Message {
    @Id
    private Integer id;
    private String source;
    private String format;
    private String data;
    private Date time;

    public Message() {
           }

    public Message(Integer id, String source, String format, String data, Date time) {
        this.id = id;
        this.source = source;
        this.format = format;
        this.data = data;
        this.time = time;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "Message{" +
                "id=" + id +
                ", source='" + source + '\'' +
                ", format='" + format + '\'' +
                ", data='" + data + '\'' +
                ", time=" + time +
                '}';
    }
}